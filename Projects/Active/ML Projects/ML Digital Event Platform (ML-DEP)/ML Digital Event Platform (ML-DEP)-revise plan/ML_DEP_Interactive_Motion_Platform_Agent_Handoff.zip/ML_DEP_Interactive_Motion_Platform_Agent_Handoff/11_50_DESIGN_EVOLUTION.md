# Existing 50 → Experience Portfolio

The existing 50 remain the heritage/base catalogue. Do not delete and replace wholesale.

Prior audit direction:
- evolve roughly 30–35 strong existing concepts;
- introduce roughly 15–20 genuinely new experience concepts;
- then freeze the final customer-facing portfolio.

Strong existing concepts identified for preservation/evolution include:
Capiz Window, Sampaguita, Sagala, Eighteen Roses, Cotillion Waltz, Sablay, Bahay Kubo, Fiesta Banderitas, Flores de Mayo, Sinulog Street, Product Launch, Class of Then, Neon Eighteen, Golden Jubilee and In Loving Memory.

Examples previously marked for merge/reposition/redesign:
- Summa Minimal → merge into stronger editorial-minimal family;
- The Long Engagement → cinematic-romance family;
- Toga and Tassel → redesign;
- Sacred Olive → print/digital keepsake;
- Handaan sa Bahay → family memory/gathering;
- Barangay Assembly → community event system;
- Parol Lights → holiday event experience.

## Required final 50 matrix
Each design must define:
Name; Experience Family; Event Compatibility; Visual Identity; Layout Profile; Motion Profile; Interaction Profile; Media Treatment; Optional Modules; Digital/Print Compatibility; Commercial Tier; Performance Class; Motion Level; Experience Signature; Action (KEEP/ENHANCE/REDESIGN/MERGE/REPOSITION/RETIRE).

## Scaling gate
Do not implement all 50 before:
1. experience seam passes;
2. gold standard passes;
3. 3–5 differentiated experiences pass;
4. mobile/performance passes;
5. operator maintainability passes.
