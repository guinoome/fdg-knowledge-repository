# Phase Gates and Definition of Done

## Phase sequence
0 Baseline  
1 Experience Engine  
2 Gold Standard Motion Experience  
3 Spoon-Fed Customer Flow  
4 Media/Remaster  
5 Catalogue Evolution  
6 RSVP/Event Participation  
7 Commerce/Publication  
8 Client-Magnet Acquisition  
9 Production Hardening  
10 Learning/Postmortem

## Explicit non-goals
Do not turn ML-DEP into:
- full CRM;
- ERP/accounting;
- generic website builder;
- Canva clone;
- general animation editor;
- social network;
- full event-management suite;
- project-management platform;
- generic CMS;
- payment platform;
- full ticketing platform in the initial scope.

## Definition of Done
### Customer
Understands product quickly, explores without account, receives relevant recommendations, enters only relevant data, uploads Original/Remaster, previews, approves, pays and obtains published invitation without technical configuration.

### Guest
Fast intentional mobile experience, meaningful motion, essential content always available, RSVP/map/calendar/share/QR work, audio controlled, memories work where enabled.

### Operator
Can manage experiences/orders/publish/RSVP/memories/consent/archive without per-customer code changes.

### Architecture
Config-driven, no presentation pollution, shared preview/publish resolution, versioned migrations, provider abstractions where justified.

### Quality
Typecheck/test/build pass, critical E2E when available, phone performance, reduced motion, accessibility, privacy/security, production smoke test, rollback known.

### Business
Real permitted prior work only; no fabricated testimonials; conversion analytics; Digital + Print; optional features packageable without code forks.

### Learning
Decisions, risks and postmortem feed the project and FDG Knowledge Repository.
