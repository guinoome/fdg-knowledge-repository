# Template, Motion and Interaction Standard

## Template = experience configuration
Required metadata:
- name/slug;
- event compatibility;
- visual identity;
- layout profile;
- motion profile;
- interaction profile;
- media treatment;
- optional modules;
- digital/print compatibility;
- commercial tier;
- performance class;
- motion level;
- experience signature;
- publish status.

## Experience signature
Every design answers:
> Why would someone remember this invitation?

If the answer is only colors/fonts, differentiation is insufficient.

## Motion levels
- M0 Static — print/fallback.
- M1 Ambient.
- M2 Structured coordinated motion.
- M3 Motion Design where choreography drives experience.
- M4 Cinematic interactive experience.

Normal digital offerings target M2–M4.

## Initial reusable motion profiles
Keep initial library small:
- Elegant
- Cinematic
- Luxury
- Playful
- Neon
- Tropical
- Storybook

## Motion principles
Motion serves anticipation, hierarchy, storytelling, orientation, feedback or emotional tone. Do not animate everything.

Respect reduced-motion. Never block essential information behind a long intro.

## Reusable interaction library
Envelope Reveal, Countdown, Music, Video Hero, Gallery, Slider, Story Timeline, Programme, Map, Calendar, RSVP, Guest Count, Guest Message, Dress Code, Entourage, Gift Registry, Ticket CTA, Speakers/Sponsors, Share, QR, Voice Message, Password, Scratch Reveal, Confetti, Page Flip, Navigation, Thank You, Memory Sharing, Guest Gallery, Live Wall.

Every module defines inputs, privacy class, mobile/accessibility behavior, failure fallback, analytics and tests.
