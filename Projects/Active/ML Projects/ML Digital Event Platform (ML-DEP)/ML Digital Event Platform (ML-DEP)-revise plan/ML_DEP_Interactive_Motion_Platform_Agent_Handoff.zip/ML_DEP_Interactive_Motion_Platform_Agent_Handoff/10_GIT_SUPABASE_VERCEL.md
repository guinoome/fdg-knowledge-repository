# Git / Supabase / Vercel Workflow

## Sources of truth
- Product code: local `mlprinting` clone → Git → GitHub.
- Project/FDG knowledge: documented architecture/decisions/learning.
- DB design: Prisma schema + migrations in Git.
- Runtime backend: Supabase.
- Production delivery: Vercel.

## Flow
```text
Local
→ audit
→ feature branch
→ implement
→ local test
→ migration validation
→ commit
→ PR/review
→ GitHub
→ controlled Supabase migration
→ Vercel preview/build
→ production
→ production verification
→ learning/postmortem
```

## Deployment rules
- Never treat successful build as full release verification.
- Verify homepage, catalogue, one invitation, RSVP, protected area, media and changed workflows.
- Know previous good deployment/commit before material release.
- Avoid destructive migrations without transition/backup plan.
- No undocumented production schema edits.
