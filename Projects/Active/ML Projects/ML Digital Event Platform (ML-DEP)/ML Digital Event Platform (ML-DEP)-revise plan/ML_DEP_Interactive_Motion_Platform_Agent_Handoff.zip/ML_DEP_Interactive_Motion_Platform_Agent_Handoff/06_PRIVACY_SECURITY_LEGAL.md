# Privacy, Security and Legal Guardrails

This is engineering/product guidance; public legal text still requires appropriate legal review.

## Marketing
No personal guest details are used in marketing.

Portfolio permission is explicit and revocable.

Consent may cover:
- invitation design;
- public invitation appearance;
- approved screenshots/promotional recording;
- specifically approved visuals.

It does not automatically cover:
- guest names;
- email/phone;
- RSVP responses;
- guest lists;
- private messages;
- private guest-generated media.

Political/campaign work defaults to portfolio exclusion.

## Guest memories
Require:
- upload notice;
- moderation;
- reporting/removal path;
- retention/deletion policy;
- organizer controls;
- access control.

Events involving minors require stricter public/marketing defaults.

## Security
- server-backed session verification;
- role/ownership authorization near protected data;
- RLS where applicable;
- upload type/size validation;
- rate limits for RSVP/upload;
- private media controls;
- no privileged admin secrets in QR;
- secrets/redaction discipline;
- provider webhooks verified where used.

## Notifications
Use contact channels under appropriate consent/service basis and provide opt-out/unsubscribe behavior where required.
