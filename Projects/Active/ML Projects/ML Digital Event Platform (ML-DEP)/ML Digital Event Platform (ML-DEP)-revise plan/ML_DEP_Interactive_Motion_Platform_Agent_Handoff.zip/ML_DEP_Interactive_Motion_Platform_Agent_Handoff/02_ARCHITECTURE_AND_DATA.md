# Target Architecture and Data

## Preserve current repository principles
- Structured invitation data is presentation-free.
- Template owns design.
- Personalization stores approved design choices, not arbitrary CSS values.
- Media is captured once and reused.
- Website and print are separate outputs from shared structured data.
- Preserve `app → features → services → lib`.
- Reuse recommendation, notification, upload, logging, feature-flag and local-db seams.

## Experience equation
`Event Data + Experience Template + Visual Theme + Motion Profile + Interaction Modules + Media Treatment = Published Invitation`

## Experience configuration
Extend existing template/layout configuration rather than duplicating it. Conceptually:

```ts
type ExperienceConfig = {
  layoutProfile: string
  motionProfile: string
  sectionOrder: string[]
  interactions: string[]
  mediaProfile: string
  performanceClass: "light" | "standard" | "cinematic"
  printProfile?: string
}
```

Exact names must follow existing code after audit.

## Renderer
Preview and published invitation must resolve from the same experience model.

## Data classes
### Public Event Data
Only intentionally published event content.

### Private Customer Data
Account/order/payment/support.

### Private Guest Data
Guest identity/contact, RSVP answers, private messages.

### Event Memory Data
Guest photos/videos/messages + moderation state.

### Portfolio Data
Only explicitly authorized design/public materials.

## New/extended concepts
Prefer extending existing models when appropriate:
- experience configuration;
- event module selections;
- media derivative linked to immutable original;
- portfolio consent;
- guest memory submission;
- live-wall settings;
- review request;
- order/payment/publication state.

Never infer portfolio permission from “invitation is public.”
