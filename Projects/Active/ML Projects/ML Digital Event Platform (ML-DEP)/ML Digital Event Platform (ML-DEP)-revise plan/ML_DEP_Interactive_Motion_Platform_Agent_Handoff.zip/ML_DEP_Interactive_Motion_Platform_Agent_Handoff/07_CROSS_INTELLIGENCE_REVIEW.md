# FDG Cross-Intelligence Review

ML-DEP remains focused. Intelligence systems contribute governance/evidence; they do not turn the product into the entire FDG ecosystem.

## FPJIS
Blueprint completeness, visualization, review, baseline, traceability, change impact, reuse, risk, assumptions/evidence, lifecycle, economics, postmortem/learning.

## FBIS
Offer architecture, pricing analysis, bundles, conversion, retention, review generation, product/revenue analytics, Digital+Print attach rate, Remaster/Live Wall/Archive economics.

## FMCIS
Capability registry, engagement lifecycle, work-package allocation, debate/review protocol, loop termination, memory/context transfer, approval gate.

Rule:
`Define work → assess available collaborators/tools/models → allocate → review`

Do not preassign everything to Codex or one model.

## FEXIS
Competitor/trend evidence, motion-design research, invitation/event-tech, Canva/Adobe/provider research, ADOPT/ADAPT/REJECT/ROADMAP.

## FWAIS
Audit→implement→test→review→deploy→verify, event-time prompts, moderation queue, archive creation, review requests, order/payment workflows.

## FSIS
Data classification, authorization, guest-upload abuse controls, secrets, storage, backup/restore.

## FLIS
Privacy/consent, portfolio permission, guest-generated media rights, retention/deletion, refunds/terms, ticketing expansion, political-project handling.

## Platform Intelligence
Keep generic service seams reusable where sensible: notifications, payments, media transformations, analytics, auth, QR.

## Service Intelligence
Approval/revision limits, event-day support, escalation, post-event delivery.

## Audit Intelligence
Before baseline/release challenge missing requirements, contradictions, duplicated capability, unsupported assumptions and architecture drift.
