# Requirements and Acceptance Matrix

| ID | Requirement | Priority | Acceptance |
|---|---|---:|---|
| UX-001 | Choose→Fill→Upload→Preview→Approve→Pay→Done | P0 | Primary journey follows sequence |
| UX-002 | Relevant dynamic questions | P0 | No giant universal form |
| UX-003 | Curated recommendations | P0 | Small relevant set + browse all |
| ARCH-001 | One experience engine | P0 | No per-design apps |
| ARCH-002 | Config-driven experiences | P0 | Layout/motion/interactions selectable by config |
| MOT-001 | M2–M4 digital motion | P0 | Coordinated motion is visible product value |
| MOT-002 | Reduced motion | P0 | Full essential experience remains |
| MEDIA-001 | Original preserved/default | P0 | Remaster never replaces original |
| MEDIA-002 | Optional Remaster | P1 | Derivative + reversible choice |
| RSVP-001 | Private mobile RSVP | P0 | Submit/confirm/dashboard access controlled |
| MEM-001 | Guest memory upload | P1 | Organizer-enabled upload works |
| MEM-002 | Moderation | P0 | No unapproved live content |
| MEM-003 | Archive | P1 | Controlled post-event delivery/export |
| NOTIF-001 | Event-time memory prompt | P1 | Schedule/provider-neutral trigger |
| NOTIF-002 | Post-event review request | P1 | Consent-aware request |
| PRIV-001 | No guest personal marketing data | P0 | Marketing path excludes private fields |
| PRIV-002 | Portfolio consent | P0 | allowed/denied/revoked |
| PRIV-003 | Political auto-portfolio exclusion | P0 | Policy enforced |
| PRINT-001 | Digital + Print matching | P1 | shared identity, separate layout needs |
| COM-001 | Approve→Pay→Publish | P1 | server/audit-controlled state |
| PERF-001 | Mobile-first | P0 | intentional phone UX |
| PERF-002 | Low-bandwidth fallback | P0 | poster/static fallback works |
| ACC-001 | Accessible interaction | P0 | keyboard/focus/labels/contrast/reduced motion |
| SEO-001 | Public discoverability | P1 | indexable catalogue/category; private invite protection |
| AN-001 | Funnel analytics | P1 | no sensitive payloads |
| OPS-001 | Versioned DB changes | P0 | migration in Git |
| OPS-002 | Production verification | P0 | smoke tests after deployment |

## Standard QA
```powershell
pnpm typecheck
pnpm test
pnpm build
```

Where available:
```powershell
pnpm test:e2e
```

Visual changes require phone viewport evidence; motion changes require a recording or equivalent evidence plus reduced-motion validation.
