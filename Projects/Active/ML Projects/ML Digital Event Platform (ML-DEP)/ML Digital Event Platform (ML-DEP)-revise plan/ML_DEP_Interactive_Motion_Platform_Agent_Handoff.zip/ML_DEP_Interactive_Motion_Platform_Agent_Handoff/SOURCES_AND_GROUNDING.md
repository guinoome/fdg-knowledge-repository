# Sources and Grounding

This package consolidates:
- the agreed ML-DEP product decisions from the project conversation;
- the uploaded Top 10 / 50-design audit material;
- verified `guinoome/mlprinting` architecture/tooling/design-language;
- FDG FPJIS, FBIS, FMCIS, FEXIS, FWAIS, FSIS, FLIS, Platform/Service/Audit intelligence concepts already identified as relevant.

Verified repository facts used:
- structured invitation data is presentation-free;
- website and print are separate outputs;
- `app → features → services → lib` dependency direction;
- Postgres/Supabase + Prisma;
- replaceable recommendation service;
- feature flags for incremental shipping;
- local PGlite DB tooling;
- Node 20+, pnpm, Next.js, Prisma, Supabase, Vitest and Playwright;
- design-language direction explicitly calls for category-selected structures, shaped photo frames, motion, video, music and QR.

The 50-design audit is still a design-review input, not a frozen final portfolio.
