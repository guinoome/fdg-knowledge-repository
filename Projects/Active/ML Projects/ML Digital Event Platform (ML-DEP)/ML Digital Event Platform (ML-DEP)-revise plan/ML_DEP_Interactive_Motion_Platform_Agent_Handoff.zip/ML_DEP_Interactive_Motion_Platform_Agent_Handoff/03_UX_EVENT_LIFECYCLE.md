# UX and Event Lifecycle

## Customer
Discover → event type → curated recommendation → choose → relevant fields → optional modules → upload → Original/Remaster → preview → approve → pay → publish → manage RSVP/memories → archive/review.

## Guest
### Before
Receive → Open → Reveal → Explore → RSVP → Map → Calendar → Share.

### During
Invitation/event prompt → QR/link → Share Memories → optional moderated gallery/live wall.

### After
Thank-you → gallery/keepsake → optional review/feedback.

## Operator
Catalogue → order review → media/remaster assistance → preview QA → approval/payment/publish → RSVP support → event memory timing/moderation → archive delivery → portfolio consent → analytics.

## Event lifecycle
### BEFORE EVENT
Invitation  
RSVP  
Countdown  
Calendar  
Map  
Information  
Programme  
Ticket CTA/information where relevant  
Social Sharing

### DURING EVENT
Memory Sharing  
QR  
Guest Upload  
Moderated Gallery  
Optional Live Memory Wall  
Social Sharing

### AFTER EVENT
Memory Archive  
Gallery  
Thank You  
Digital Keepsake  
Printed Keepsake  
Review Request

## Post-event review
Client and, where appropriate/consented, guests may receive an email/SMS/Messenger/in-app link asking for honest feedback/review. Never require a positive review.
