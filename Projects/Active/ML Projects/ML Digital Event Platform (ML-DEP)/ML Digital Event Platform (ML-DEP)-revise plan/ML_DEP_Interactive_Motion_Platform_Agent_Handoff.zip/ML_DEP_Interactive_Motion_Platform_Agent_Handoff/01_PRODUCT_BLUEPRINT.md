# Product Blueprint

## Product
ML-DEP is an **Interactive Motion Invitation Platform** operated by ML Printing.

It combines:
- premium visual design;
- motion/animation;
- interactive reveals;
- event information;
- countdown;
- photo/video;
- music;
- RSVP;
- guest information;
- maps;
- calendar;
- QR;
- social sharing;
- optional matching print;
- order/payment;
- event-day memory participation;
- post-event archive/review.

## Event scope
Generic event architecture supports, without separate apps:
Wedding, Birthday, Debut, Christening, Anniversary, Baby Shower, Graduation, Reunion, Corporate, Conference, Seminar, Product Launch, Concert, Festival, Raffle, Community, Religious, Memorial, School, Private Party, Fundraiser, Ticketed Event, Political/Campaign, Custom.

Political/campaign projects default to private/custom portfolio handling.

## Customer-visible experience
`Choose → Fill → Upload → Preview → Approve → Pay → Done`

### Choose
Ask what is being celebrated/hosted and optionally style preference.

### Recommend
Show a small curated set (for example ~6) before exposing the full catalogue.

### Fill
Ask only relevant fields. Suggested optional modules can include programme, entourage, dress code, FAQ, accommodation, transportation, gifts, speakers, sponsors or ticket information.

### Upload
`Use Original` is default. `Remaster` is optional.

Suggested copy:
> Remaster your photos — Give your selected photos a polished digital finish while keeping the original images available.

Never tell the customer “your photo is low quality.” Where useful:
> This photo may work better with a different crop for this design.

### Preview / Approve / Pay / Done
Use the same resolved experience model intended for publication. Approval and payment become controlled states before publication.

## Acquisition
Public site should:
- communicate the proposition immediately;
- show real interactive previews;
- allow no-account exploration;
- use real previous ML Printing work only with permission;
- connect Digital + Print;
- lead clearly to inquiry/order.
