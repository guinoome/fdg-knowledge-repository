# Media, Event Memories and Commerce

## Original / Remaster
- Original is default.
- Never overwrite original.
- Remaster creates a derivative linked to original.
- Customer can revert to Original.
- Provider-neutral remaster service/adapter.
- Canva/Adobe/other services may assist asset creation/enhancement; none becomes the invitation runtime.

## Design-suitability guidance
Internally the platform may evaluate dimensions, orientation, aspect ratio, crop-safe area, file compatibility and slot compatibility.

Customer-facing guidance is practical, not judgmental.

## Event Memory Sharing
Example:
> Share Your Memories  
> Having a great time? Share your photos and videos with the celebrants.

Personalized:
> Share Your Memories with Maria & Jose

Entry points: invitation, QR, event link, venue display, optional notification provider.

Modes:
- Private Collection
- Guest Gallery
- Live Memory Wall
- Post-Event Archive

Hard rule: no unapproved guest-generated content on a public/live display. Initial live-wall release defaults to manual approval.

## Commerce
Flow:
`Preview → Approve → Order → Pay → Publish/Deliver`

Payment stays behind an adapter and requires server-validated state. Client redirects alone do not prove payment.

Packaging candidates (pricing not locked):
- Digital Invitation
- Premium/Motion
- Digital + Print
- Remaster
- Memory Sharing
- Live Memory Wall
- Memory Archive
- Custom Experience

Ticketed events initially support ticket/event CTA and information. Do not prematurely build a full ticketing platform.
