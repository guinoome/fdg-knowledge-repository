# Agent Work Packages

FMCIS assigns actual agents/models/tools after capability assessment.

## WP-00 Baseline Audit
Audit current repo, tests, visual behavior, builder, catalogue, website generator, media, RSVP, order/payment seams. No product changes.

## WP-01 Experience Configuration Seam — START CODING HERE
Goal: template-selected structure/motion/interactions without duplicated apps.

Tasks:
- inspect existing layout registry/template config;
- define minimal typed experience config;
- implement resolver;
- preserve presentation-free invitation data;
- connect preview and published runtime to same resolved model;
- protect with feature flag;
- prove two materially different layouts.

Exit: two templates differ structurally without separate applications.

## WP-02 Gold Standard Motion Invitation
Opening reveal, motion hero, countdown, story/programme, gallery, video where relevant, music control, venue/map, calendar, RSVP, share, QR, mobile, reduced-motion, fallback.

## WP-03 Spoon-Fed Recommendation Flow
Event type/preferences → reuse recommendation service → curated subset → browse all → relevant fields/modules.

## WP-04 Original/Remaster
Immutable original + derivative workflow + provider abstraction + reversible selection.

## WP-05 50-Design Metadata
Experience signature, layout/motion/interaction/media profiles, motion level, performance class, compatibility and status. Do not redesign all 50 here.

## WP-06 RSVP Intelligence
Counts, attending/declined/pending, authorized guest detail, search/filter/export.

## WP-07 Event Memory Sharing
Enablement, active window, QR/link, upload, moderation, private/gallery modes.

## WP-08 Live Memory Wall
Approved-only display, moderation UX, update strategy, fallback.

## WP-09 Notifications/Post-Event
Event memory prompt, archive delivery, thank-you/review workflow. Provider-neutral first.

## WP-10 Approval/Order/Payment/Publish
Auditable state machine and controlled publication.

## WP-11 Digital + Print
Matching design identity while keeping renderers independent.

## WP-12 Client-Magnet Acquisition
Homepage, real previews, permitted prior work, curated discovery, CTA, SEO.

## WP-13 Security/Privacy Hardening
RLS/ownership/rate limits/uploads/consent/private media.

## WP-14 Production Release
QA, migrations, preview/staging, production deploy, smoke verification, rollback, learning capture.
