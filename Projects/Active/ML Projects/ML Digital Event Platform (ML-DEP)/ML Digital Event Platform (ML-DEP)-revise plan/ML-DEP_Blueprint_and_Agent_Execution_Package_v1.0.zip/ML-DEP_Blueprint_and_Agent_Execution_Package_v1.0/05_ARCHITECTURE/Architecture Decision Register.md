# Architecture Decision Register
ADR-001 One Experience Engine.  
ADR-002 Motion First: M2–M3 default, M4 selective.  
ADR-003 Reduced Motion Mandatory.  
ADR-004 Content/Presentation Separation.  
ADR-005 Local-First Development.  
ADR-006 GitHub Version Control.  
ADR-007 Supabase Runtime Backend.  
ADR-008 Vercel Production Target.  
ADR-009 Bounded Customer Editor.  
ADR-010 Memory is a reusable module.  
ADR-011 Commercial complexity 18 CORE / 24 SIGNATURE / 8 IMMERSIVE.  
ADR-012 Preserve historical evidence and superseded material.
