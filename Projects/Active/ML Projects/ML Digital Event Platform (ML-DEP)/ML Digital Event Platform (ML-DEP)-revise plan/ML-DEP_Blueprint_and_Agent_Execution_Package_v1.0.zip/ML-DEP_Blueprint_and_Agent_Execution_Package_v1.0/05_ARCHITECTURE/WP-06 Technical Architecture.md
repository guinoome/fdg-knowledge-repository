# WP-06 Technical Architecture
**Status:** BASELINED

Do not rebuild ML-DEP. Evolve the current Next.js/Supabase/Prisma/Vercel architecture.

Core equation: `Event Data + Experience Configuration + Visual Theme + Motion Profile + Interaction Modules + Media = Published Experience`.

ExperienceConfig minimum: id, version, name, family, eventCompatibility, layoutId, visualThemeId, motionProfileId, interactionProfileIds, mediaProfileId, sectionOrder, optionalModules, commercialTier, performanceClass, motionLevel, accessibilityProfileId, printCompatibility, status.

Domains: Public; Customer; Experience Engine; Event Utility; Event Memory; Commerce; Administration.

Boundary rules: routes compose features; shared services are reused; customer content stays presentation-free; designs configure rather than fork the engine; current layout registry/renderer/media/RSVP/QR/music/marketplace/personalization/auth/test patterns are inspected and reused before new code.

Deployment: Local → validation → Git → GitHub → CI → controlled Supabase changes → Vercel → production verification.
