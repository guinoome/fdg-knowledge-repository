# WP-07 Data Architecture
**Status:** BASELINED

Domains: Identity; Event; Experience; Invitation; Media; Guest; Memory; Commerce; Consent/Governance; Portfolio; Review; Analytics.

Event data describes WHAT. Experience data describes HOW. Media Library owns assets. Commerce owns transactions. Consent owns permission. Analytics observes.

Migration rule: design locally → local/test DB → tests → commit migration → review → controlled Supabase apply → production verification → evidence.

Never store actual secrets in Markdown, Git, agent reports or chat.
