# Accessibility Performance Security
Accessibility: reduced motion, keyboard, semantic controls/forms, focus, contrast, no hover-only critical action, no autoplay audio, no motion-only information.

Performance: P1 lightweight; P2 enhanced/default; P3 immersive with lazy loading and graceful degradation. Validate mid-range mobile, slow network, media optimization and P3 isolation.

Security: auth, authorization/ownership, RLS where applicable, upload validation, rate/abuse controls, RSVP protection, memory moderation state, payment isolation, secret protection, audit logs, backup/recovery, consent/deletion.
