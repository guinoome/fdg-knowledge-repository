# ML-DEP Product Experience Blueprint
ML-DEP is a motion-first digital invitation and event experience platform connected to ML Printing's physical print products.

## Principles
1. Motion-first, not animation-for-animation's-sake.
2. Mobile is primary; desktop is adaptation.
3. One configurable engine, not one app per invitation.
4. Customer chooses content and approved options; platform controls design logic.
5. Preserve original media; Remaster is optional.
6. Digital + print are complementary outputs.
7. Event lifecycle spans before, during and after.
8. Personal data is not marketing content.
9. Local/Filipino identity is strategic differentiation.
10. Evidence and baselines govern implementation.

## Customer journey
What are you celebrating? → recommended experiences → Fill → Upload → Preview → Approve → Pay → Done.

## Customer-editable
Names, dates/times, venue/map, messages, photos/video, approved music, RSVP, programme, dress code, story/entourage, ticket information, approved modules.

## Platform-controlled
Responsive layout, typography hierarchy, motion choreography, interaction mechanics, performance, accessibility and approved design vocabulary.

## Lifecycle
Before: invitation, RSVP, countdown, calendar, map, programme, sharing.
During: QR, guest memory upload, optional live wall.
After: memory archive, gallery, thank-you, digital/print keepsake, review request.

## Privacy
Marketing permission is separate from service delivery. Guest lists, contact data, RSVPs, private messages and private uploads are not portfolio content. Political/campaign work is excluded from normal public portfolio unless separately authorized.
