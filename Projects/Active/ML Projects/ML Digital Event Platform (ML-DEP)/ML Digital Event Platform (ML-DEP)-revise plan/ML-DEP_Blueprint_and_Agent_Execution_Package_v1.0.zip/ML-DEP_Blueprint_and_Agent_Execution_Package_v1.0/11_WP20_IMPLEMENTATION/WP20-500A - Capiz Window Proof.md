# WP20-500A Capiz Window Proof
SIGNATURE/P2/M3/MP-14. Prove cultural premium experience through common engine. Signature: Light travels through layered capiz panes before revealing the couple and ceremony. Mobile/tablet/desktop, reduced motion, tests, visual evidence.
