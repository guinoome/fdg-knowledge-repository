# WP20-100 Experience Engine
Priority P0. Evolve current architecture into configuration-driven experience resolution. Reuse layout registry. Acceptance: no separate app per experience; at least three materially different experiences resolve through one engine; configuration testable; reduced-motion derivable.
