# WP20-200 Shared Visual Primitives
Priority P1. Reuse/build shaped media frames, date treatments, typography, rule frames, ornaments, photo strips, responsive sections, media surfaces and loading/fallback states. Experience-agnostic, mobile-first, accessible.
