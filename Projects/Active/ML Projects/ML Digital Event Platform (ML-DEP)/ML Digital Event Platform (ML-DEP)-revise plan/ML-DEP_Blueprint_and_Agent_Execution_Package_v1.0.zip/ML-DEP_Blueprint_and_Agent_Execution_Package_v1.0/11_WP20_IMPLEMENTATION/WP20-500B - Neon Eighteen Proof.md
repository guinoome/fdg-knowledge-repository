# WP20-500B Neon Eighteen Proof
IMMERSIVE/P3/M4/MP-09. Stress-test high motion/media without breaking common engine. Progressive effects, usable before immersive load, reduced motion, no autoplay audio, P3 isolation.
