# WP20-300 Motion System
Priority P1. Implement MP-01..MP-15 as reusable profiles with normal + reduced-motion modes, performance compatibility and no animation-gated information.
