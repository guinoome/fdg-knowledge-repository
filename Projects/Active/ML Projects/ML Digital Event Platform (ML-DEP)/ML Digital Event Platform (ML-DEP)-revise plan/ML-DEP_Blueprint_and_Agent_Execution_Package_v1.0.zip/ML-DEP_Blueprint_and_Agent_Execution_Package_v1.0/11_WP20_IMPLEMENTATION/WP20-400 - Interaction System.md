# WP20-400 Interaction System
Priority P1. Normalize IX-01..IX-20. Existing RSVP/music/QR/map/calendar are reused, not rewritten solely for uniformity. Include accessibility, errors and security for public inputs.
