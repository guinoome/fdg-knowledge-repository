# WP20-700 Customer Journey
Implement What are you celebrating? → recommendations → choose → dynamic questions → media → Original/Remaster → preview → approve → pay → publish. Low decision burden, no giant form, preserved originals, mobile-first.
