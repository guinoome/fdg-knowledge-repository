# WP20-800 Event Memory
Guest upload, QR, publication mode, moderation state, live wall, archive, post-event gallery. Modes: Private / Auto-Publish eligible / Moderated. Secure uploads, rate/abuse control, privacy/deletion.
