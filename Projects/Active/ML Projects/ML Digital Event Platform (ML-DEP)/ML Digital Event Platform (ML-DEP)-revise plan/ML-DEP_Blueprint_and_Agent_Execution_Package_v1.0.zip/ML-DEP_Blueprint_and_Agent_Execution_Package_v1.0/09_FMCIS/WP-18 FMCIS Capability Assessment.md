# WP-18 FMCIS Capability Assessment
Agent count is dynamic. Use the least costly/most available agent that can meet the Definition of Done without increasing risk.

Lead/Architecture Agent: repository-wide work, shared abstractions, schema, complex integration. Codex-class repository agent recommended.  
Feature Agent: bounded feature.  
UI Agent: approved visual implementation.  
Motion Agent: motion primitives/profiles.  
Data Agent: schema/migrations/Supabase reconciliation.  
Test Agent: unit/integration/E2E/regression.  
Audit Agent: independent acceptance.

Free agents are for bounded work with explicit contracts. They do not receive architecture authority.
