# Source and Evidence Register
Local path was supplied by the owner on 2026-08-29. Package generation did not directly inspect that Windows filesystem, therefore WP20-000 local inspection is mandatory.

GitHub evidence used during planning: `https://github.com/guinoome/mlprinting` with Next.js/React/TypeScript, Supabase/Prisma, invitation builder, marketplace, seeded catalogue, website generator, layout registry, hero/video, countdown, music, RSVP, QR, media and architecture/design docs.

FDG governance reference: `https://github.com/guinoome/fdg-knowledge-repository`.

Owner states ML-DEP is connected to Vercel and Supabase. Agents must verify current linkage/state; historical connection is not proof of current correctness.
