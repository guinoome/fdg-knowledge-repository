# ML-DEP Governance and Change Control
DRAFT → REVIEW → APPROVED → BASELINED → IMPLEMENTED → VALIDATED → LEARNED

A BASELINED artifact is not silently changed. Material changes create a Change Request and new revision.

Agents may inspect, implement, test, refactor within baseline, report defects and propose changes. They may not redefine product scope, override the Final 50, weaken accessibility, replace architecture without review, erase history, force-push, or overwrite local work to match GitHub.
