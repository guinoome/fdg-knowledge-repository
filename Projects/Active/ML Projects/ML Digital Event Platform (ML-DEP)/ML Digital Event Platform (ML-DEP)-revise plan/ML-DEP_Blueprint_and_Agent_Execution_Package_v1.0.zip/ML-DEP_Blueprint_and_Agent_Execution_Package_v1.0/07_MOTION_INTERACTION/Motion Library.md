# Motion Library
M0 Static fallback; M1 Ambient; M2 Structured; M3 Motion Design; M4 Cinematic.

MP-01 Editorial Reveal — P1/P2  
MP-02 Elegant Depth — P2  
MP-03 Cinematic Opening — P3  
MP-04 Envelope Ceremony — P2  
MP-05 Kinetic Type — P2  
MP-06 Organic Bloom — P2  
MP-07 Memory Journey — P1/P2  
MP-08 Celebration Burst — P2  
MP-09 Neon Pulse — P2/P3  
MP-10 Festival Motion Poster — P2/P3  
MP-11 Product Reveal — P3  
MP-12 Quiet Tribute — P1  
MP-13 Glass/Liquid — P3  
MP-14 Cultural Ceremony — P2  
MP-15 Story Scroll — P2/P3

Every profile defines normal and reduced-motion behavior. No essential information may depend on animation.
