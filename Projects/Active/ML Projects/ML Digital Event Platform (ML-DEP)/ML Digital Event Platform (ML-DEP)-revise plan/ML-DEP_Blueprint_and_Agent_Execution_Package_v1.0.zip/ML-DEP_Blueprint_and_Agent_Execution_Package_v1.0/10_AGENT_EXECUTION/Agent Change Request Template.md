# ML-DEP Change Request
CR ID:  
Origin WP:  
Agent:  
Baseline affected:  
Problem:  
Evidence:  
Proposed change:  
Alternatives:  
Impact — Product/UX/Architecture/Data/Security/Performance/Commercial/Migration/Testing:  
Decision: DRAFT / REVIEW / APPROVED / REJECTED  
Approver:  
New baseline revision:
