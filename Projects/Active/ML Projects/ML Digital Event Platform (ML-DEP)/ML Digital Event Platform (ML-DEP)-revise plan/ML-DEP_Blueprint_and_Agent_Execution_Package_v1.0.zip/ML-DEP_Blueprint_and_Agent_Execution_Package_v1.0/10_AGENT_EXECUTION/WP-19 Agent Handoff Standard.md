# WP-19 Agent Handoff Standard
Every WP contains: ID, title, priority, dependencies, role, baseline, objective, scope, out-of-scope, likely files, outputs, acceptance criteria, tests, evidence and Definition of Done.

Agents first read baseline, inspect code, identify reuse, run baseline tests, confirm dependencies, then implement the smallest compliant change.

Completion evidence: changes, files, tests/results, visual evidence, performance/accessibility evidence where relevant, migrations, unresolved risks, docs update, and baseline deviation NONE or linked approved Change Request.
