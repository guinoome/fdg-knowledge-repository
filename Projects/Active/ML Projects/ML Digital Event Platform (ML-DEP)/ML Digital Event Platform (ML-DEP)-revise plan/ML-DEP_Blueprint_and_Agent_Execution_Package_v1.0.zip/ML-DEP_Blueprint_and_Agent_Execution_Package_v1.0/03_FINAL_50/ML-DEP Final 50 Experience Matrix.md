# ML-DEP Final 50 Experience Matrix

**Status:** BASELINED v1.0

| ID | Experience | Family | Source | Primary Events | Tier | Perf | Motion | Motion Profile | Experience Signature |
|---:|---|---|---|---|---|---|---|---|---|
| 1 | Ivory Lace | Luxury/Romantic | Existing | Wedding | SIGNATURE | P2 | M3 | MP-01 | Animated lace opens into an editorial wedding story. |
| 2 | Blush Botanical | Botanical/Romantic | Existing | Wedding/Engagement | SIGNATURE | P2 | M3 | MP-06 | Botanical elements bloom around the couple as the story unfolds. |
| 3 | Midnight Gold | Luxury/Editorial | Existing | Wedding/Gala | SIGNATURE | P2 | M3 | MP-02 | Metallic details emerge from a cinematic midnight field. |
| 4 | Coastal Linen | Destination/Romantic | Existing | Wedding/Private | CORE | P2 | M2 | MP-02 | A coastal scene reveals the event like a destination journal. |
| 5 | Gilded Vow | Luxury/Romantic | Existing | Wedding | SIGNATURE | P2 | M3 | MP-03 | Gold-line choreography introduces the ceremony like a formal title sequence. |
| 6 | Sampaguita | Filipino/Cultural | Existing | Wedding/Religious | SIGNATURE | P2 | M3 | MP-14 | Sampaguita garlands bloom into a distinctly Filipino wedding story. |
| 7 | Capiz Window | Filipino/Cultural Luxury | Existing | Wedding/Anniversary | SIGNATURE | P2 | M3 | MP-14 | Light travels through layered capiz panes before revealing the couple and ceremony. |
| 8 | Confetti Pop | Celebration | Existing | Birthday/Party | CORE | P2 | M2 | MP-08 | Kinetic type and confetti make the invitation feel like the party has started. |
| 9 | First Year | Family/Memory | Existing | First Birthday | CORE | P1 | M2 | MP-07 | A child’s first-year photos become the invitation itself. |
| 10 | Cake Smash | Kids/Celebration | Existing | Kids Birthday | SIGNATURE | P2 | M3 | MP-08 | Balloons and reveal interactions turn the invite into a mini game. |
| 11 | Golden Sixty | Milestone/Luxury | Existing | Milestone Birthday | CORE | P1 | M2 | MP-01 | A milestone numeral opens into a polished photo story. |
| 12 | Seventh Heaven | Fantasy/Kids | Existing | 7th Birthday | SIGNATURE | P2 | M3 | MP-08 | A fairytale world reveals the celebration through playful discovery. |
| 13 | Neon Eighteen | Youth/Nightlife | Existing | Debut/Birthday | IMMERSIVE | P3 | M4 | MP-09 | The debut feels like entering a live nightlife event. |
| 14 | Eighteen Roses | Filipino/Debut | Existing | Debut | SIGNATURE | P2 | M3 | MP-14 | The eighteen-rose tradition becomes an interactive ceremonial sequence. |
| 15 | Cotillion Waltz | Debut/Formal | Existing | Debut | SIGNATURE | P2 | M3 | MP-03 | Dance-inspired choreography structures the invitation around the programme. |
| 16 | Sagala | Filipino/Cultural | Existing | Debut/Religious/Community | SIGNATURE | P2 | M3 | MP-14 | Ceremonial florals and procession structure create a local experience. |
| 17 | Blue Hour | Cinematic/Portrait | Existing | Debut/Engagement | SIGNATURE | P2 | M3 | MP-03 | Dusk photography and controlled motion create a cinematic portrait. |
| 18 | Little Dove | Religious/Family | Existing | Christening/Baptism | CORE | P1 | M2 | MP-12 | A restrained dove reveal creates a calm ceremonial invitation. |
| 19 | Sweet Dreams | Family/Fantasy | Existing | Baby Shower/Kids | SIGNATURE | P2 | M3 | MP-06 | A star field connects into a constellation around the celebration. |
| 20 | Golden Jubilee | Memory/Anniversary | Existing | Anniversary | SIGNATURE | P2 | M3 | MP-07 | Then-and-now photos transition across decades of shared memory. |
| 21 | Still Us | Story/Anniversary | Existing | Anniversary/Engagement | SIGNATURE | P2 | M3 | MP-07 | Guests move through an interactive relationship timeline. |
| 22 | Sablay | Filipino/Achievement | Existing | Graduation | CORE | P1 | M2 | MP-01 | The portrait and sablay become a proud achievement reveal. |
| 23 | Quarterly Gala | Corporate/Luxury | Existing | Corporate Gala/Awards | CORE | P1 | M2 | MP-01 | A polished executive invitation presents the programme with restrained motion. |
| 24 | Product Launch | Corporate/Product | Existing | Product Launch | IMMERSIVE | P3 | M4 | MP-11 | The invitation reveals the product like a launch campaign. |
| 25 | Boardroom Black | Corporate/Formal | Existing | Awards/Executive | SIGNATURE | P2 | M3 | MP-02 | Event details unfold as a cinematic formal presentation. |
| 26 | Noche Buena | Filipino/Family | Existing | Christmas/Family | CORE | P1 | M2 | MP-08 | Holiday imagery unfolds like a family Christmas card brought to life. |
| 27 | Bahay Kubo | Filipino/Family | Existing | Family/Community | SIGNATURE | P2 | M3 | MP-14 | A living Filipino garden guides guests into the gathering. |
| 28 | Fiesta Banderitas | Filipino/Festival | Existing | Fiesta/Community | SIGNATURE | P2 | M3 | MP-10 | The invitation behaves like a living town-fiesta poster. |
| 29 | Santo Patrón | Religious/Community | Existing | Fiesta/Religious | CORE | P1 | M2 | MP-14 | The procession programme and map become the ceremonial journey. |
| 30 | Reunion Table | Family/Reunion | Existing | Family/Reunion | CORE | P1 | M2 | MP-07 | Family history and event details gather around a shared table story. |
| 31 | Class of Then | Memory/Reunion | Existing | Class Reunion | SIGNATURE | P2 | M3 | MP-07 | Guests move from old class photos to present-day memories. |
| 32 | Sealed with Yes | Engagement/Romantic | Existing | Engagement | SIGNATURE | P2 | M3 | MP-04 | A sealed announcement opens into the couple’s story. |
| 33 | Flores de Mayo | Filipino/Cultural | Existing | Religious/Community | SIGNATURE | P2 | M3 | MP-14 | Floral procession stages reveal the programme and celebration. |
| 34 | Sinulog Street | Filipino/Festival | Existing | Festival/Community | IMMERSIVE | P3 | M4 | MP-10 | A festival poster comes alive with street rhythm and motion. |
| 35 | In Loving Memory | Memorial/Keepsake | Existing | Memorial/Funeral | CORE | P1 | M2 | MP-12 | A quiet portrait preserves dignity while service information remains effortless to find. |
| 36 | The Atelier | Luxury/Editorial | NEW | Wedding/Gala/Anniversary | SIGNATURE | P2 | M3 | MP-01 | An editorial fashion-book sequence turns invitation details into a luxury spread. |
| 37 | Ivory Editorial | Modern/Minimal | NEW | Wedding/Graduation/Corporate | CORE | P1 | M2 | MP-01 | Large typography and disciplined whitespace create a timeless experience. |
| 38 | The Opening Scene | Cinematic | NEW | Wedding/Debut/Launch | IMMERSIVE | P3 | M4 | MP-03 | The invitation begins like the opening scene of a film. |
| 39 | Love in Motion | Cinematic/Romantic | NEW | Wedding/Engagement/Anniversary | IMMERSIVE | P3 | M4 | MP-03 | The couple’s story flows through cinematic chapters. |
| 40 | 35mm | Film/Memory | NEW | Wedding/Reunion/Birthday | SIGNATURE | P2 | M3 | MP-07 | Photos advance like a film contact sheet and memory reel. |
| 41 | Liquid Light | Digital Luxury | NEW | Wedding/Corporate/Launch | IMMERSIVE | P3 | M4 | MP-13 | Refraction and liquid light reshape the interface as the invitation unfolds. |
| 42 | Opaline | Digital Luxury | NEW | Wedding/Debut/Gala | SIGNATURE | P2 | M3 | MP-13 | Translucent opal layers shift gently around the event story. |
| 43 | Aurora | Modern/Digital | NEW | Birthday/Debut/Corporate | IMMERSIVE | P2 | M3 | MP-13 | Gradient light behaves like an aurora moving through each section. |
| 44 | The Story | Interactive Story | NEW | Wedding/Anniversary/Reunion | CORE | P2 | M3 | MP-15 | The invitation is experienced as a guided story with chapters. |
| 45 | Memory Lane | Interactive Memory | NEW | Anniversary/Reunion/Memorial | CORE | P1 | M2 | MP-07 | Guests travel through dated memories before arriving at the event. |
| 46 | Disco | Youth/Celebration | NEW | Birthday/Debut/Party | CORE | P2 | M3 | MP-09 | Beat-like light and typography make the invite feel like a club poster. |
| 47 | Festival Pulse | Live/Ticketed | NEW | Concert/Festival/Ticketed | IMMERSIVE | P3 | M4 | MP-10 | A live-event poster pulses into programme, ticket and venue information. |
| 48 | Main Stage | Live/Event | NEW | Concert/Conference/Festival | CORE | P2 | M3 | MP-10 | Guests move from headline act to schedule to venue like an event lineup. |
| 49 | Summit | Corporate/Conference | NEW | Conference/Seminar/Corporate | CORE | P1 | M2 | MP-01 | A structured conference experience prioritizes speakers, schedule and attendance. |
| 50 | Innovation | Corporate/Technology | NEW | Technology/Product/Corporate | CORE | P2 | M2 | MP-11 | A future-facing product narrative presents agenda and innovation themes with controlled motion. |

## Portfolio controls
- 18 CORE
- 24 SIGNATURE
- 8 IMMERSIVE
- M2–M3 normal target; M4 selective.
- Reduced-motion behavior mandatory.
- Static M0 is fallback/print, not normal digital product.

## Consolidated seed concepts
- Summa Minimal → editorial/minimal configuration.
- The Long Engagement → cinematic/story romantic configuration.
- Sacred Olive → religious/keepsake visual theme.
- Handaan sa Bahay → family gathering configuration.
- Barangay Assembly → Community Event configuration.
- Parol Lights → seasonal holiday visual direction.
- Eternal Olive → memorial keepsake/media profile.

Ticketing, raffle/fundraising, civic/community and campaign-event support are reusable modules rather than separate codebases. Campaign/political work is excluded from ordinary portfolio publication unless separately authorized.
