---
title: "ML-DEP Blueprint and Agent Execution Package"
project: "ML Digital Event Platform (ML-DEP)"
version: "1.0"
status: "BASELINED"
implementation_authority: "WP-20 AUTHORIZED"
date_baselined: "2026-08-29"
---
# ML-DEP Blueprint and Agent Execution Package v1.0

Canonical local working repository:
`C:\Users\FraNc!s\Documents\Obsidian\FDG Knowledge Repository\Projects\Active\ML Projects\ML Digital Event Platform (ML-DEP)`

GitHub remote: `https://github.com/guinoome/mlprinting`

Connected services: Vercel production deployment and Supabase backend.

## Governing rule
The local repository is inspected first. GitHub is the versioned remote reference. Supabase is the connected runtime/cloud data service. Vercel is the production deployment target. An agent MUST reconcile all four states before changing code.

## Baseline state
- WP-01 Product Experience Blueprint — BASELINED
- WP-02 Final-50 Experience System — BASELINED
- WP-03 Visualization — BASELINED at blueprint level
- WP-04 Blueprint Review — PASS
- WP-05 Baseline — APPROVED
- WP-06 Technical Architecture — BASELINED
- WP-07 Data Architecture — BASELINED
- WP-18 FMCIS Capability Assessment — BASELINED
- WP-19 Agent Handoff Architecture — BASELINED
- WP-20 Implementation — AUTHORIZED

## Product proposition
**A digital invitation that feels like an experience.**

**Beautiful enough to share. Interactive enough to remember. Practical enough to manage your event.**

**Your digital invitation can match your printed invitation.**

## Customer journey
**Choose → Fill → Upload → Preview → Approve → Pay → Done**

## Architecture principle
`Event Data + Experience Configuration + Visual Theme + Motion Profile + Interaction Modules + Media = Published Experience`

## Change control
BASELINED artifacts are immutable by default. Material change requires:
`Finding → Change Request → Impact Analysis → REVIEW → APPROVAL → New Baseline Revision`.
