# Mandatory Reading Order
Before coding, every agent reads:
1. ML-DEP-0000
2. ML-DEP-0002 Pre-Coding Readiness Gate
3. Governance and Change Control
4. Product Experience Blueprint
5. Final 50 Experience Matrix
6. WP-03 Visualization Specification
7. WP-06 Technical Architecture
8. WP-07 Data Architecture
9. Motion Library
10. Interaction Library
11. Accessibility Performance Security
12. WP-18 FMCIS Capability Assessment
13. WP-19 Agent Handoff Standard
14. Assigned WP-20 work package

No coding begins until the readiness gate is signed off.
