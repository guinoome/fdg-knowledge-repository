# Pre-Coding Readiness Gate
## Purpose
Prevent rework caused by stale assumptions, mismatched local/remote code, undocumented Supabase state, or unverified Vercel deployment state.

## Step 1 — Inspect the actual local repository
Path:
`C:\Users\FraNc!s\Documents\Obsidian\FDG Knowledge Repository\Projects\Active\ML Projects\ML Digital Event Platform (ML-DEP)`

Record repository root, git status, branch, HEAD, untracked/modified files, package manager, schema/migrations, tests, renderer, layout registry, media, marketplace, builder, auth, commerce code if present, deployment docs.

**Hard rule:** discovery is read-only. Do not reset, clean, rebase, force-checkout, delete, or overwrite.

## Step 2 — Compare local to GitHub
Remote: `https://github.com/guinoome/mlprinting`
Create `PRECHECK_LOCAL_GITHUB_DIFF.md` and classify each difference: SAFE LOCAL WORK / SAFE REMOTE WORK / CONFLICT / UNKNOWN / MUST PRESERVE / REQUIRES OWNER DECISION.

## Step 3 — Establish current test baseline
Run supported install verification, build, typecheck, lint, unit, integration, E2E if configured. Record existing failures BEFORE implementation.

## Step 4 — Inspect Supabase state
Verify project identity, schema version, migration history, relevant tables, RLS, storage, auth, runtime functions and environment-variable names. Never expose secret values. Create `PRECHECK_SUPABASE_STATE.md`.

## Step 5 — Inspect Vercel state
Verify project, GitHub linkage, production branch, latest deployment, build status, env-var names, framework/build settings and public behavior. Never expose secrets. Create `PRECHECK_VERCEL_STATE.md`.

## Step 6 — Reconcile documentation
If old docs describe a solved problem, preserve them, record supersession, and do not solve it twice.

## Step 7 — Readiness decision
Create `WP20_READINESS_REPORT.md` with READY / READY WITH RECORDED LIMITATIONS / BLOCKED. If BLOCKED, coding is prohibited.
