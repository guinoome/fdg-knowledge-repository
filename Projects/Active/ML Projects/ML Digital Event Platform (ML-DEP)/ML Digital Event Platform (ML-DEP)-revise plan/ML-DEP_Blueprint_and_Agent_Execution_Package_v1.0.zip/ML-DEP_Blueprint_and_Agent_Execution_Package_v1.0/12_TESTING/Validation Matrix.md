# Validation Matrix
Functional: catalogue, recommendations, builder, media, preview/approval, RSVP/map/calendar/programme/QR/music/share, commerce/memory when implemented.  
Visual: mobile/tablet/desktop, representative CORE/SIGNATURE/IMMERSIVE, cultural and memorial.  
Accessibility: keyboard/focus/contrast/reduced-motion/audio/semantics.  
Performance: P1 isolation, media/lazy/poster, mid-range mobile, slow network.  
Security: auth/role/ownership/RLS/public-input abuse/uploads/secrets/payment.  
Deployment: local, GitHub CI/build, Supabase migration evidence, Vercel preview and production smoke.
